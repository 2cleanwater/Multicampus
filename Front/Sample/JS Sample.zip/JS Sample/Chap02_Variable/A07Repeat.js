
console.log('---------------- Loop Statument -----------------');

var result = 0;

