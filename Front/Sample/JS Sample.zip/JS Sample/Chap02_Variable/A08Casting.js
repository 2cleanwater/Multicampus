
console.log('---------------- Casting -----------------');

// 명시적 형 변환(타입 캐스팅)
var x = 10;
console.log("x: " + x + ', typeof(변수명): ' + typeof(x));



// 암묵적 타입 변환 (강제 타입 변환)

