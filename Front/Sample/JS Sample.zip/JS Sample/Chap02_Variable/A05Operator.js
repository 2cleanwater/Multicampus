
console.log('---------------- Logical Operator -----------------');

var x = 10;
var y = 5;
var z = 5;
var result;

result = (x > y) && (x > y);
console.log('(x > y) && (x > y) => ' + result);

// 연산자로 사용.
var age;


