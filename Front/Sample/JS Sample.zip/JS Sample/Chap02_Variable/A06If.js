
console.log('---------------- Conditional Statument -----------------');


console.log('');


var kor, eng, avg;
kor = 100;
eng = 60;
avg = (kor + eng) / 2;

// 단순 IF


// IF ~ ELSE



// 다중 IF


// switch
var year = 2000;
var month = 2;
var day = 0;

