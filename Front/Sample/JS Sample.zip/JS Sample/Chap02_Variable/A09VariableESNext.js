
console.log('---------------- Casting -----------------');

var nickname = 'NolBu';
var nickname = 'HungBu';

{
    var nickaname = 'BangJa';
}
console.log("nickname: " + nickname);
console.log('');


// let
