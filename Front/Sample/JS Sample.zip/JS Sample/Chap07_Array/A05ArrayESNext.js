
console.log('---------------- Array Callback -----------------');

// ES6
var ary = [10, 11, 100, 101, 1000, 1001];






var objArray = [
    {id: 1, name: 'NolBu', age: 35}, 
    {id: 2, name: 'BangJa', age: 18}, 
    {id: 3, name: 'HungBu', age: 25}
];

function findItem(index) {
    return objArray[index];
};



