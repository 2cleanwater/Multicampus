
console.log('---------------- Array -----------------');

var ary = [10, 11, 100, 101, 1000, 11, 100];






console.log('---------------- Sort -----------------');

var names = [ 'NolBu', 'BangJa', 'HungBu' ];

