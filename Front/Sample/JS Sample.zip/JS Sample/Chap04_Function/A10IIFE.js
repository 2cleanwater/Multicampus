
console.log('---------------- Closure -----------------');
// Immediately Invoked Function Expression

