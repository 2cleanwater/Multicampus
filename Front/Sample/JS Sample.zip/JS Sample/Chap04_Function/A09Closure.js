
console.log('---------------- Closure -----------------');

let num = 0;

const incOne = function() {
    
};
