
console.log('---------------- Closure -----------------');

var x = 10;

function one() {
    var x = 'one';
}

function two() {
    console.log(x);
};


