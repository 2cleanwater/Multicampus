
console.log('--------------- spread Object ---------------')
const obj = {
    name: 'NolBu',
    age: 30
};




console.log('--------------- spread Array ---------------')
const ary = [10, 11, 100];
const aryOne = [20, 21, 200];

