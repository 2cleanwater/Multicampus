
console.log('---------------- Primary Type And Reference Type-----------------');

var numA = 100;
var numB = numA;

// 비교





var objA = {
    name: 'NolBu',
    age: 30,
};

var objB = objA;
