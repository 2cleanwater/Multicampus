
console.log('---------------- Object -----------------');

var x = 10;
var str = 'Hello World';

var obj = {
    x: x,
    str: str
}
console.log(obj);
console.log('');


// 계산된 프로퍼티 이름
var prefix = 'prop'

