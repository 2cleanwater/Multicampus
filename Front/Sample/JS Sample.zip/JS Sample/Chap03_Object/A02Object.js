
console.log('---------------- Object -----------------');

var obj = {
    name: 'NolBu',
    address: 'Seoul',
    info: function() {
        console.log(this.name + ' / ' + this.address);
    }
};


